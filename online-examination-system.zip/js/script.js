const answers = {
  q1: "Keyboard",
  q2: "Hyper Text Markup Language",
  q3: "CSS",
  q4: "Central Processing Unit",
  q5: "Chrome",
};

function startTimer(durationInMinutes = 30) {
  const timerEl = document.getElementById("timer");
  if (!timerEl) return;

  let remaining = durationInMinutes * 60;

  const tick = () => {
    const minutes = String(Math.floor(remaining / 60)).padStart(2, "0");
    const seconds = String(remaining % 60).padStart(2, "0");
    timerEl.textContent = `${minutes}:${seconds}`;

    if (remaining <= 0) {
      clearInterval(interval);
      autoSubmit();
      return;
    }
    remaining--;
  };

  tick();
  const interval = setInterval(tick, 1000);

  function autoSubmit() {
    const form = document.getElementById("examForm");
    if (form) form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
  }
}

function calculateScore(formData) {
  let score = 0;
  const total = Object.keys(answers).length;

  for (const key in answers) {
    if (formData.get(key) === answers[key]) score++;
  }

  return { score, total };
}

function saveResult(score, total) {
  localStorage.setItem("examScore", String(score));
  localStorage.setItem("examTotal", String(total));
  localStorage.setItem("examMessage", score >= total / 2 ? "Good job!" : "Keep practicing!");
}

function renderResultPage() {
  const scoreText = document.getElementById("scoreText");
  const resultMsg = document.getElementById("resultMsg");

  if (!scoreText || !resultMsg) return;

  const score = localStorage.getItem("examScore");
  const total = localStorage.getItem("examTotal");
  const msg = localStorage.getItem("examMessage") || "Submit the exam to see your result.";

  if (score && total) {
    scoreText.textContent = `${score}/${total}`;
    resultMsg.textContent = msg;
  } else {
    scoreText.textContent = "0/5";
    resultMsg.textContent = "Submit the exam to see your result.";
  }
}

function setupExamForm() {
  const form = document.getElementById("examForm");
  const clearBtn = document.getElementById("clearBtn");

  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = new FormData(form);
    const { score, total } = calculateScore(data);
    saveResult(score, total);
    window.location.href = "result.html";
  });

  if (clearBtn) {
    clearBtn.addEventListener("click", () => form.reset());
  }

  startTimer(30);
}

document.addEventListener("DOMContentLoaded", () => {
  setupExamForm();
  renderResultPage();
});
