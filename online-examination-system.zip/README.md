# Online Examination System

A simple college mini project website built using HTML, CSS, and JavaScript.

## Files
- `index.html` - Home page
- `exam.html` - Exam interface
- `result.html` - Score display
- `about.html` - Project information
- `css/style.css` - Shared styling
- `js/script.js` - Timer and scoring logic

## Features
- Multi-page structure
- Timer-based exam
- Multiple-choice questions
- Auto score calculation
- Result page using local storage
- Responsive design

## How to Run
Open `index.html` in any browser.

## Note
This is a front-end demo project. No backend or database is included.
